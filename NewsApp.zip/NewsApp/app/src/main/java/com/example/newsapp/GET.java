package com.example.newsapp;

public @interface GET {
}
